# Homework #2 submission pack

- `L02/README.md` — complete report structure, **raw results pending**.
- `L02/prompts/` — five original required prompt patterns (copy one message at a time).
- `L02/dataset.md` — M1–M8 test messages.
- `L02/reference_answers.md` — expected categories for evaluation; these are **not observed model outputs**.
- `instructor_materials/` — three untouched original Markdown files from the provided ZIP.

## To finish

1. Pick a standard model, note its exact name and today's execution date.
2. Run each specified test in a fresh/temporary chat, following `instructor_materials/L02_Homework_Guide_EN.md`.
3. Paste unedited responses into `L02/README.md`, replacing every `[PASTE RAW OUTPUT]` field.
4. Calculate measured metrics, write conclusions, and replace the student identifier.
5. Commit `L02/README.md` in the repository branch and submit the pull request.

The report is **not a completed experiment** until those observations are supplied.
